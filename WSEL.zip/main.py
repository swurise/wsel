if __name__ == "__main__":
    codepath=config.basepath+'/codes'
    datapath = config.basepath+'/datasets'
    mypath = datapath + '/'+config.dataset
    print(mypath)